import { Input } from "@/components/ui/input";
import { useState } from "react";

const recipes = [
  "Alligator Crawfish Chili Pot",
  "Brisket Business",
  "For the Love of Lambchops",
  "Italian Alfredo Gator Burger",
  "Seafood Chili",
  "Seafood Stack",
  "What a Seabass",
  "When Surf Meets Turf"
];

export default function RecipeIndex() {
  const [query, setQuery] = useState("");
  const filtered = recipes.filter(name => name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Recipe Index</h1>
      <Input
        placeholder="Search recipes..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="mb-4"
      />
      <ul className="list-disc pl-5 space-y-1">
        {filtered.map((recipe, idx) => (
          <li key={idx} className="text-base">
            {recipe}
          </li>
        ))}
      </ul>
    </div>
  );
}
