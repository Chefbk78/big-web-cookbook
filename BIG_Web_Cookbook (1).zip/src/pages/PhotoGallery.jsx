import { Card, CardContent } from "@/components/ui/card";
import { Image } from "@/components/ui/image";

const galleryItems = [
  { title: "Italian Alfredo Gator Burger", src: "/images/gator-burger.jpg" },
  { title: "When Surf Meets Turf", src: "/images/surf-turf.jpg" },
  { title: "Brisket Business", src: "/images/brisket.jpg" },
  { title: "What a Seabass", src: "/images/seabass.jpg" },
  { title: "For the Love of Lambchops", src: "/images/lambchops.jpg" },
  { title: "Alligator Crawfish Chili Pot", src: "/images/crawfish-chili.jpg" },
  { title: "Seafood Stack", src: "/images/seafood-stack.jpg" },
  { title: "Seafood Chili", src: "/images/seafood-chili.jpg" }
];

export default function PhotoGallery() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Photo Gallery</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {galleryItems.map((item, idx) => (
          <Card key={idx} className="overflow-hidden">
            <Image
              src={item.src}
              alt={item.title}
              className="w-full h-64 object-cover"
            />
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold text-center">{item.title}</h2>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
