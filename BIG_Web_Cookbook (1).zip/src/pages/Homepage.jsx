import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function Homepage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold">B.I.G. – But It's Greasy</h1>
        <p className="text-lg text-muted-foreground mt-2">By Chef BK</p>
        <p className="mt-4 max-w-xl mx-auto text-base">
          A bold, unapologetic collection of Southern soul and culinary swagger—seasoned to perfection and served with love.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Greasy Grills</h2>
            <ul className="list-disc pl-4 space-y-1">
              <li><Link to="/recipes/italian-alfredo-gator-burger">Italian Alfredo Gator Burger</Link></li>
              <li><Link to="/recipes/for-the-love-of-lambchops">For the Love of Lambchops</Link></li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Seafood Soul</h2>
            <ul className="list-disc pl-4 space-y-1">
              <li><Link to="/recipes/what-a-seabass">What a Seabass</Link></li>
              <li><Link to="/recipes/when-surf-meets-turf">When Surf Meets Turf</Link></li>
              <li><Link to="/recipes/seafood-stack">Seafood Stack</Link></li>
              <li><Link to="/recipes/alligator-crawfish-chili-pot">Alligator Crawfish Chili Pot</Link></li>
              <li><Link to="/recipes/seafood-chili">Seafood Chili</Link></li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Southern Smokes</h2>
            <ul className="list-disc pl-4 space-y-1">
              <li><Link to="/recipes/brisket-business">Brisket Business</Link></li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <Button variant="outline" asChild>
          <Link to="/gallery">View Photo Gallery</Link>
        </Button>
        <Button className="ml-4" asChild>
          <Link to="/index">Recipe Index</Link>
        </Button>
      </div>
    </div>
  );
}
