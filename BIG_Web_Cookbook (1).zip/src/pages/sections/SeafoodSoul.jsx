# Seafood Soul

## What a Seabass

**Ingredients:**
- 2 seabass fillets (cleaned and deboned)
- 1 tbsp seafood seasoning
- 1 cup frozen corn
- 2 tbsp butter
- Salt and pepper, to taste

**Cheesy Grits Base:**
- 1 cup quick grits
- 4 cups water or broth
- 1/2 cup shredded cheddar cheese
- Salt and pepper, to taste

**Fresh Pico de Gallo:**
- 1 tomato, diced
- 1/2 mango, diced
- 1/4 red onion, finely chopped
- 1 tbsp lemon juice
- Salt and pepper, to taste
- Pinch of Tajín

**Instructions:**
1. Season seabass and cook until flaky.
2. Sauté frozen corn in butter with salt and pepper.
3. Prepare cheesy grits as base.
4. Mix fresh pico ingredients.
5. Stack grits, corn, seabass, and fresh pico.

---

## When Surf Meets Turf

**Ingredients:**
- 1 lb flank or skirt steak
- 4 oz cream cheese
- 1 cup spinach
- 4 slices Prosciutto
- 1/2 cup grated Parmesan
- Onion powder, salt, pepper, jalapeño salt

**Creamy Shrimp Topping:**
- 1 lb shrimp
- 2 tbsp butter
- 1 cup heavy cream
- 1 tsp seafood seasoning

**Instructions:**
1. Season and layer steak with cream cheese, spinach, Prosciutto, Parmesan, and seasoning.
2. Roll, secure with butcher’s twine. Bake 250°F for 30 min covered. Broil 8 min.
3. Cook shrimp in butter, add cream and seasoning. Simmer until thick.
4. Slice steak and top with shrimp.

---

## Seafood Stack

**Ingredients:**
- 1/2 lb shrimp
- 1/2 lb crab or fried oysters
- 1/2 cup buttermilk
- 1/2 cup cornmeal
- 1/2 cup flour
- Cajun seasoning, garlic powder, paprika, salt, pepper
- Oil for frying

**Herb Sauce:**
- 1/2 cup mayo
- 1 tbsp lemon juice
- 1 tbsp parsley or dill
- Garlic, salt, pepper

**Stacking Layers:**
- Pineapple slices
- Microgreens or arugula

**Instructions:**
1. Fry shrimp (and oysters if used).
2. Mix herb sauce.
3. Stack: greens, pineapple, seafood, drizzle sauce.

---

## Alligator Crawfish Chili Pot

**Ingredients:**
- 1 lb ground alligator
- 1/2 lb crawfish tails
- 1 tbsp oil
- Onion, celery, bell pepper
- Garlic, canned tomatoes, sauce
- Chili powder, paprika, cumin, cayenne, bouillon, seasonings

**Instructions:**
1. Sauté trinity, garlic. Add gator. Cook 15 min.
2. Add tomatoes, sauce, spices, crawfish.
3. Simmer 30 min. Serve hot.

Where the sea meets soul—with fire and bold flavor from Chef BK.
