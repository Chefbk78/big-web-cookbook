# Greasy Grills

## Italian Alfredo Gator Burger

**Ingredients:**
- 1/2 lb alligator meat (cut into bite-sized pieces)
- 1/2 lb Italian sausage
- 1/2 lb ground beef
- Salt, to taste
- Pepper, to taste
- Garlic powder, to taste
- Cajun seasoning, for alligator
- Vegetable oil, for frying

**Alfredo Sauce Ingredients:**
- 2 tbsp butter
- 1 cup heavy cream
- 1 tsp garlic powder
- Salt, to taste
- Pepper, to taste
- 1 tsp Sriracha (or more to taste)

**Instructions:**
1. Combine Italian sausage and ground beef. Season with salt, pepper, and garlic powder. Form into patties and cook on grill or skillet until done.
2. Season alligator with Cajun seasoning. Fry in 350°F oil for 7–8 minutes until golden and floating. Drain.
3. In a saucepan, melt butter and add heavy cream. Stir in garlic powder, salt, pepper, and Sriracha. Simmer until slightly thickened.
4. Assemble the burger: bun, patty, Alfredo sauce, fried gator, more sauce, bun. Serve hot.

---

## For the Love of Lambchops

**Ingredients:**
- 6 lamb chops
- 1 tsp red pepper flakes
- 1 tsp salt
- 1 tsp black pepper
- 1 tbsp Worcestershire sauce
- 1 tbsp blackened seasoning
- 2 cloves fresh garlic, minced

**Instructions:**
1. Create a marinade with all ingredients. Marinate lamb chops at least 2 hours.
2. **Grill Option:** Grill at 275°F for 4 min per side, until internal temp hits 145°F.
3. **Oven Option:** Bake at 275°F for 35 min covered in foil, then broil uncovered on low for 12 min.
4. Let rest 5 min. Serve.

These grilled plates are greasy, seasoned, and built for flavor—straight from Chef BK’s fire to your fork.
