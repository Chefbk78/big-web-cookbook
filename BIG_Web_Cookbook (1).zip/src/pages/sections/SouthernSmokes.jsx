# Southern Smokes

## Brisket Business

**Ingredients:**
- 1 whole beef brisket (flat and point)
- Coarse salt
- Coarse black pepper
- Garlic powder

**Instructions:**
1. Generously coat brisket with a blend of coarse salt, pepper, and garlic powder.
2. Set BBQ pit to 300°F. Maintain this temp the entire cook time.
3. Place brisket meat side up, unwrapped, and cook for 3 hours.
4. Wrap brisket in foil or butcher paper. Return to pit fat side up.
5. Cook an additional 4 hours, or until internal temp reaches 195°F to 205°F.
6. Let brisket rest 35 to 45 minutes in the open wrap.
7. Slice against the grain and serve hot.

Smoked, rested, and richly seasoned—this is brisket done the B.I.G. way, by Chef BK.
